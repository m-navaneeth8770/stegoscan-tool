from flask import Flask, render_template, request, redirect, url_for
import os
import json
from steg.detector import detect_steganography
from steg.extractor import extract_stego_data
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads/'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

SUPPORTED_METHODS = ["LSB", "StegHide", "F5", "Palette LSB"]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/scan', methods=['POST'])
def scan():
    if 'file' not in request.files:
        return redirect(url_for('index'))

    file = request.files['file']
    if file.filename == '':
        return redirect(url_for('index'))

    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)

    # Detection
    detected, methods, scores, confidence, suspected = detect_steganography(filepath)

    # Extraction if supported
    extraction_attempted = suspected in SUPPORTED_METHODS
    if extraction_attempted:
        status, summary, error = extract_stego_data(filepath, suspected)

        # If extraction failed and it's a no-message error, override detection
        if status == "failure" and error and "No readable message found in LSB" in error:
            detected = False
            methods = []
            suspected = None
            confidence = 0.0
    else:
        status = "not_attempted"
        summary = None
        error = None

    # Report generation
    report = {
        "file_name": filename,
        "file_type": file.content_type,
        "scan_date": request.date if hasattr(request, 'date') else None,
        "detection": {
            "steganography_detected": detected,
            "detection_methods": methods,
            "anomaly_scores": scores,
            "suspected_method": suspected,
            "confidence": confidence
        },
        "extraction": {
            "attempted": extraction_attempted,
            "method_used": suspected if extraction_attempted else None,
            "extraction_status": status,
            "extracted_data_summary": summary,
            "extraction_errors": error
        },
        "notes": ("Extraction succeeded." if extraction_attempted and status == "success"
                  else "Extraction failed." if extraction_attempted and status == "failure"
                  else "Method unsupported or unknown."),
        "recommendations": []
    }
    if extraction_attempted and status == "success":
        report['recommendations'].append("Review the extracted data.")
    elif extraction_attempted and status == "failure":
        report['recommendations'].append("Check password or try manual tools.")
    else:
        report['recommendations'].append("Consider manual inspection using StegSolve or adding support for this method.")

    # Save JSON report
    report_path = os.path.join(app.config['UPLOAD_FOLDER'], f"{filename}_report.json")
    with open(report_path, 'w') as f:
        json.dump(report, f, indent=4)

    return render_template('report.html', report=report)

if __name__ == '__main__':
    app.run(debug=True)
