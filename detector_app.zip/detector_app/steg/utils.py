# steg/utils.py
import subprocess

def run_command(cmd_list):
    """
    Run a command via subprocess and return (stdout, stderr).
    """
    proc = subprocess.Popen(cmd_list, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = proc.communicate()
    return out.decode(errors='ignore'), err.decode(errors='ignore')