# steg/detector.py (Enhanced video analysis with temporal LSB difference + frame sampling)
import os
from PIL import Image
import numpy as np
from steg.utils import run_command
from collections import Counter
import math
import magic
import cv2

def calculate_entropy(data_bytes):
    counts = Counter(data_bytes)
    total = len(data_bytes)
    ent = 0
    for count in counts.values():
        p = count / total
        ent -= p * math.log2(p)
    return ent

def sample_pair_analysis(arr):
    diff = np.abs(arr[:, :-1] - arr[:, 1:])
    abnormal = np.sum(diff == 1)
    ratio = abnormal / diff.size
    return ratio > 0.3

def rs_attack(arr):
    try:
        flat = arr.flatten()
        r_count = np.sum(flat % 2 == 0)
        s_count = np.sum(flat % 2 == 1)
        rs_ratio = abs(r_count - s_count) / len(flat)
        return rs_ratio > 0.2
    except:
        return False

def weighted_stego_attack(arr):
    grad_x = np.abs(np.diff(arr, axis=1))
    grad_y = np.abs(np.diff(arr, axis=0))
    weight = np.mean(grad_x) + np.mean(grad_y)
    return weight < 1.5

def triples_attack(arr):
    try:
        rows, cols = arr.shape[:2]
        triples = arr[:, :cols - 2] + arr[:, 1:cols - 1] + arr[:, 2:]
        std = np.std(triples)
        return std < 3.0
    except:
        return False

def advanced_frame_score(arr):
    score = 0
    if sample_pair_analysis(arr):
        score += 1.5
    if rs_attack(arr):
        score += 1.5
    if weighted_stego_attack(arr):
        score += 1.0
    if triples_attack(arr):
        score += 1.0
    lsb = arr & 1
    var = float(np.var(lsb))
    if var > 0.05:
        score += 2.0
    return score

def temporal_lsb_difference(frame1, frame2):
    gray1 = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
    gray2 = cv2.cvtColor(frame2, cv2.COLOR_BGR2GRAY)
    diff = cv2.absdiff(gray1, gray2)
    arr = np.array(diff)
    lsb = arr & 1
    var = float(np.var(lsb))
    return var > 0.03

def frame_level_video_analysis(filepath, scores):
    cap = cv2.VideoCapture(filepath)
    total_score = 0
    high_score_frames = 0
    prev_frame = None
    count = 0
    frame_indices = []
    frame_scores = []

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        if count % 10 == 0:  # sample every 10th frame
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            arr = np.array(gray)

            frame_score = advanced_frame_score(arr)
            total_score += frame_score

            temporal_flag = False
            if prev_frame is not None:
                temporal_flag = temporal_lsb_difference(prev_frame, frame)

            suspicious = (frame_score >= 4) or temporal_flag
            if suspicious:
                high_score_frames += 1

            frame_indices.append(count)
            frame_scores.append(frame_score)

            prev_frame = frame

        count += 1

    cap.release()
    scores['video_frames_analyzed'] = len(frame_indices)
    scores['video_high_score_frames'] = high_score_frames
    scores['video_frame_score_sum'] = total_score
    scores['video_avg_frame_score'] = round(total_score / max(len(frame_indices), 1), 2)

    return (scores['video_avg_frame_score'] >= 3.0 or high_score_frames >= 3)

def detect_steganography(filepath):
    methods = set()
    scores = {}
    suspected = None

    mime = magic.from_file(filepath, mime=True)
    scores['mime_type'] = mime

    with open(filepath, 'rb') as f:
        raw = f.read()

    # Video file
    if mime.startswith('video'):
        ent = calculate_entropy(raw)
        scores['entropy'] = round(ent, 3)
        try:
            if frame_level_video_analysis(filepath, scores):
                methods.add('Frame-Level LSB Indicators')
                suspected = 'LSB'
                return True, list(methods), scores, 0.9, suspected
            else:
                return False, [], scores, 0.1, None
        except Exception as e:
            return False, [], {"note": f"Video analysis failed: {str(e)}"}, 0.0, None

    # WAV audio
    if mime.startswith('audio') and filepath.lower().endswith('.wav'):
        import wave
        import struct
        try:
            wav = wave.open(filepath, 'rb')
            frames = wav.readframes(wav.getnframes())
            sample_width = wav.getsampwidth()
            channels = wav.getnchannels()
            fmt = {1: 'B', 2: 'h', 4: 'i'}.get(sample_width)
            if not fmt:
                return False, [], {"note": "Unsupported WAV format"}, 0.0, None
            data = struct.unpack('<' + fmt * (len(frames) // sample_width), frames)
            lsb_list = [sample & 1 for sample in data]
            ones = sum(lsb_list)
            zeros = len(lsb_list) - ones
            ratio = ones / (ones + zeros)
            scores['lsb_ratio'] = round(ratio, 3)
            if 0.45 < ratio < 0.55:
                methods.add('Audio LSB Uniformity')
                suspected = 'LSB'
                return True, list(methods), scores, 0.85, suspected
            else:
                return False, [], scores, 0.1, None
        except Exception as e:
            return False, [], {"note": f"Audio detection failed: {str(e)}"}, 0.0, None

    # Image entropy
    ent = calculate_entropy(raw)
    scores['entropy'] = round(ent, 3)
    if filepath.lower().endswith(('.jpg', '.jpeg')) and ent >= 7.95:
        methods.add('High Entropy')
        suspected = suspected or 'F5'
    elif filepath.lower().endswith(('.png', '.bmp')) and ent >= 7.95:
        methods.add('Medium Entropy')

    if not filepath.lower().endswith(('.jpg', '.jpeg')):
        try:
            img = Image.open(filepath).convert('L')
            arr = np.array(img)
            if arr.size == 0:
                return False, [], scores, 0.0, None
            if sample_pair_analysis(arr):
                methods.add('Sample Pair Analysis')
                suspected = suspected or 'LSB'
            if rs_attack(arr):
                methods.add('RS Attack')
                suspected = suspected or 'LSB'
            if weighted_stego_attack(arr):
                methods.add('Weighted Stego Attack')
                suspected = suspected or 'LSB'
            if triples_attack(arr):
                methods.add('Triples Attack')
                suspected = suspected or 'LSB'
            lsb = arr & 1
            var = float(np.var(lsb))
            scores['bit_plane_variance'] = round(var, 4)
            if var > 0.05:
                methods.add('Bit-plane Anomaly')
                suspected = suspected or 'LSB'
        except Exception as e:
            print("Image processing failed:", e)

    detected = len(methods) >= 2
    confidence = round(min(1.0, (len(methods) * 0.25 + (ent / 10))), 2)
    return detected, list(methods), scores, confidence, suspected
