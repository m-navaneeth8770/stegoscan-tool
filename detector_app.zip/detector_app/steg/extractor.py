# steg/extractor.py
import os
import numpy as np
from steg.utils import run_command
from PIL import Image
import wave
import struct

def extract_stego_data(filepath, method):
    ext = os.path.splitext(filepath)[-1].lower()

    if method == 'LSB':
        try:
            if ext in ['.png', '.bmp']:
                from stegano import lsb
                img = Image.open(filepath).convert("RGB")
                message = lsb.reveal(img)
                if not message:
                    return 'failure', None, 'No LSB message found.'
                summary = {
                    'data_type': 'text',
                    'data_preview': message[:200],
                    'data_size_bytes': len(message.encode('utf-8'))
                }
                if not summary['data_preview'].strip():
                    return 'failure', None, 'No readable message found in LSB.'
                return 'success', summary, None

            elif ext == '.wav':
                wav = wave.open(filepath, 'rb')
                frames = wav.readframes(wav.getnframes())
                sample_width = wav.getsampwidth()
                fmt = {1: 'B', 2: 'h', 4: 'i'}.get(sample_width)
                if not fmt:
                    return 'failure', None, 'Unsupported audio sample width.'
                data = struct.unpack('<' + fmt * (len(frames) // sample_width), frames)
                bits = [(sample & 1) for sample in data]
                chars = []
                for i in range(0, len(bits) - 7, 8):
                    byte = bits[i:i+8]
                    val = int(''.join(map(str, byte)), 2)
                    if val == 0:
                        break
                    chars.append(chr(val))
                message = ''.join(chars)
                if not message.strip():
                    return 'failure', None, 'No readable message found in LSB.'
                summary = {
                    'data_type': 'text',
                    'data_preview': message[:200],
                    'data_size_bytes': len(message.encode('utf-8'))
                }
                return 'success', summary, None

            else:
                return 'failure', None, f'LSB extraction not supported for {ext.upper()} files.'

        except Exception as ex:
            return 'failure', None, f'LSB extractor error: {str(ex)}'

    elif method == 'StegHide':
        return extract_steghide(filepath)

    else:
        return 'failure', None, f'Method {method} not implemented.'

def extract_steghide(filepath):
    try:
        out, err = run_command(['steghide', 'extract', '-sf', filepath, '-p', ''])
        if 'wrote extracted data to' in out:
            summary = {
                'data_type': 'file',
                'data_preview': 'Extracted to working directory.',
                'data_size_bytes': 0
            }
            return 'success', summary, None
        else:
            return 'failure', None, err
    except Exception as ex:
        return 'failure', None, str(ex)
