import cv2
import numpy as np
import os
import scipy.stats as stats

def calculate_entropy(gray_frame):
    """
    Calculate the Shannon entropy of a grayscale frame.
    """
    hist = cv2.calcHist([gray_frame], [0], None, [256], [0, 256])
    hist_norm = hist.ravel() / hist.sum()
    hist_norm = hist_norm[hist_norm > 0]
    return -np.sum(hist_norm * np.log2(hist_norm))


def detect_lsb_chisq(gray_frame, significance=0.01):
    """
    Perform a chi-square test on the distribution of LSB bits in a grayscale frame.
    Returns True if the p-value is above `significance`, indicating an unusually balanced LSB plane.
    """
    lsb_bits = np.bitwise_and(gray_frame, 1).ravel()
    counts = np.bincount(lsb_bits, minlength=2).astype(np.float64)  # [count of 0s, count of 1s]
    expected = np.array([len(lsb_bits) / 2, len(lsb_bits) / 2])
    chi2, p_value = stats.chisquare(counts, expected)
    return p_value > significance


def detect_video_steg(video_path):
    """
    Scan a video file for possible steganographic content using:
      1) Frame-level LSB chi-square analysis
      2) High entropy in frames (indicating possible DCT/statistical embedding)
      3) Presence of a ".meta_hidden.txt" file for hidden metadata
    Returns a dictionary with detection results, any extracted message, and recommendations.
    """
    report = {
        "Scan Report for": os.path.basename(video_path),
        "Detection": {
            "Detected": False,
            "Methods": [],
            "Suspected Method": None,
            "Confidence": 0.0
        },
        "Extraction": {
            "Attempted": False,
            "Status": "not attempted",
            "Errors": None,
            "Message": None
        },
        "Recommendations": "None"
    }

    try:
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            report["Extraction"]["Errors"] = "Error opening video file"
            return report

        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        if frame_count == 0:
            report["Extraction"]["Errors"] = "Video has no frames"
            cap.release()
            return report

        # Choose up to 30 frames evenly spaced across the video
        sample_count = min(30, frame_count)
        indices = np.linspace(0, frame_count - 1, num=sample_count, dtype=int)

        entropy_values = []
        lsb_hits = 0
        frames_checked = 0

        for idx in indices:
            cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
            ret, frame = cap.read()
            if not ret:
                continue

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            entropy = calculate_entropy(gray)
            entropy_values.append(entropy)

            if detect_lsb_chisq(gray, significance=0.01):
                lsb_hits += 1

            frames_checked += 1

        cap.release()

        if frames_checked == 0:
            report["Extraction"]["Errors"] = "Could not read any frames"
            return report

        avg_entropy = float(np.mean(entropy_values))
        lsb_ratio = lsb_hits / frames_checked

        # Debug prints (optional; uncomment if you want to log these values):
        # print(f"[DEBUG] Frames checked: {frames_checked}")
        # print(f"[DEBUG] LSB hits: {lsb_hits}, LSB ratio: {lsb_ratio:.3f}")
        # print(f"[DEBUG] Average entropy: {avg_entropy:.3f}")

        # Detection logic:
        # 1) If more than 50% of sampled frames have suspiciously balanced LSBs → LSB stego suspected.
        # 2) Else if average entropy > 7.0 → possible DCT/statistical stego.
        if lsb_ratio > 0.50:
            report["Detection"]["Detected"] = True
            report["Detection"]["Methods"].append("Frame-Level LSB (Chi-Square)")
            report["Detection"]["Suspected Method"] = "LSB"
            report["Detection"]["Confidence"] = round(lsb_ratio, 2)
        elif avg_entropy > 7.0:
            report["Detection"]["Detected"] = True
            report["Detection"]["Methods"].append("High Frame Entropy")
            report["Detection"]["Suspected Method"] = "DCT/Statistical"
            report["Detection"]["Confidence"] = 0.7

        # Check for a hidden metadata file alongside the video
        hidden_file = video_path + ".meta_hidden.txt"
        if os.path.exists(hidden_file):
            with open(hidden_file, "r") as f:
                hidden_msg = f.read().strip()
            report["Detection"]["Detected"] = True
            report["Detection"]["Methods"].append("Metadata Channel")
            report["Detection"]["Suspected Method"] = "Metadata"
            report["Detection"]["Confidence"] = 1.0
            report["Extraction"]["Attempted"] = True
            report["Extraction"]["Status"] = "success"
            report["Extraction"]["Message"] = hidden_msg
        else:
            # No hidden metadata file found
            report["Extraction"]["Attempted"] = True
            report["Extraction"]["Status"] = "not attempted"

        # Final recommendation based on detection outcome
        if report["Detection"]["Detected"]:
            report["Recommendations"] = (
                "Consider using specialized stego-extraction tools or "
                "re-examining with different parameters."
            )
        else:
            report["Recommendations"] = (
                "No strong steganographic signs detected. "
                "If you suspect hidden data, try manual inspection or "
                "alternative stego detection tools."
            )

    except Exception as e:
        report["Extraction"]["Errors"] = f"Error: {str(e)}"

    return report


if __name__ == "__main__":
    video_file = "cover.mp4"  # Change this to the path of the video you want to scan
    scan_result = detect_video_steg(video_file)
    for key, value in scan_result.items():
        print(f"{key}: {value}")
