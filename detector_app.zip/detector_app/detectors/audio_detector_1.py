import wave
from pydub import AudioSegment

def extract_lsb_audio(audio_in):
    audio = wave.open(audio_in, mode='rb')
    frames = bytearray(audio.readframes(audio.getnframes()))
    audio.close()

    bits = [str(frame & 1) for frame in frames]
    message = ''
    for i in range(0, len(bits), 8):
        byte = bits[i:i+8]
        char = chr(int(''.join(byte), 2))
        message += char
        if '###' in message:
            message = message.split('###')[0]
            break
    return message

def extract_metadata_audio(audio_in):
    audio = AudioSegment.from_wav(audio_in)
    if audio.tags and 'comment' in audio.tags:
        return audio.tags.get('comment', '')
    else:
        return ''

def detect_audio_steg(audio_path):
    result = []
    detected = False

    try:
        message = extract_lsb_audio(audio_path)
        if message:
            result.append(f"✅ LSB Extracted Message: {message}")
            result.append("✅ Detected: LSB Stego")
            detected = True
    except:
        pass

    try:
        comment = extract_metadata_audio(audio_path)
        if comment:
            result.append(f"✅ Metadata Extracted Message: {comment}")
            result.append("✅ Detected: Metadata Stego")
            detected = True
    except:
        pass

    if not detected:
        result.append("❌ No known steganography detected.")

    return result
