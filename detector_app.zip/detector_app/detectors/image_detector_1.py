from PIL import Image
import numpy as np
import os

def universal_stego_detector(image_path):
    results = []
    results.append(f"Analyzing: {image_path}")

    try:
        img = Image.open(image_path)
        data = np.array(img)
    except Exception as e:
        results.append(f"❌ Error opening image: {e}")
        return results

    # ---- LSB Detection ----
    try:
        rgb_data = data[:, :, :3].flatten()
        bits = [bin(pixel)[-1] for pixel in rgb_data]
        message_bits = []
        for i in range(0, len(bits), 8):
            byte = bits[i:i+8]
            if len(byte) < 8:
                break
            char = chr(int(''.join(byte), 2))
            if char == '\x00' or not char.isprintable():
                break
            message_bits.append(char)
        message = ''.join(message_bits)
        if message:
            results.append(f"✅ LSB Extracted Message: {message}")
            results.append("✅ Detected: LSB Stego")
            return results
    except Exception as e:
        results.append(f"⚠️ LSB detection failed: {e}")

    # ---- Metadata Detection ----
    try:
        info = img.info
        if info:
            for key, value in info.items():
                results.append(f"✅ Metadata Key: {key} => {value}")
            results.append("✅ Detected: Metadata Stego")
            return results
    except Exception as e:
        results.append(f"⚠️ Metadata check failed: {e}")

    # ---- Simulated Steghide Detection ----
    try:
        hidden_file = image_path + ".steghide_hidden.txt"
        if os.path.exists(hidden_file):
            with open(hidden_file, "r") as f:
                message = f.read()
                results.append(f"✅ Steghide Extracted Message: {message}")
                results.append("✅ Detected: Simulated Steghide Stego")
                return results
    except Exception as e:
        results.append(f"⚠️ Steghide simulation check failed: {e}")

    # ---- Simulated DCT Detection ----
    try:
        hidden_file = image_path + ".dct_hidden.txt"
        if os.path.exists(hidden_file):
            with open(hidden_file, "r") as f:
                message = f.read()
                results.append(f"✅ DCT Extracted Message: {message}")
                results.append("✅ Detected: Simulated DCT Stego")
                return results
    except Exception as e:
        results.append(f"⚠️ DCT simulation check failed: {e}")

    results.append("❌ No known steganography detected.")
    return results
