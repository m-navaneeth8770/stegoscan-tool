from flask import Flask, request, render_template, jsonify
from detectors.image_detector import universal_stego_detector
import os

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/detect', methods=['POST'])
def detect_stego():
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided.'}), 400

    file = request.files['file']
    file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(file_path)

    result = universal_stego_detector(file_path)
    return jsonify({'result': result})

if __name__ == '__main__':
    app.run(debug=True)
